﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace FlagQuiz
{
    public class FlagQuizController
    {
        private List<String> flagPaths = new List<string>();
        public List<int> flagsAvailable = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8 };

        public List<Flag> flags = new List<Flag>();
        public bool available = false;

        public Flag currentFlag = new Flag();

        public FlagQuizController()
        {
            PopulateFlags();
        }
        public void PopulateFlags()
        {
            flags.Add(new FlagQuiz.Flag(1, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\australia.png","Australia"));
            flags.Add(new FlagQuiz.Flag(2, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\brazil.png","Brazil"));
            flags.Add(new FlagQuiz.Flag(3, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\china.png","China"));
            flags.Add(new FlagQuiz.Flag(4, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\italy.png","Italy"));
            flags.Add(new FlagQuiz.Flag(5, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\russia.png","Russia"));
            flags.Add(new FlagQuiz.Flag(6, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\southafrica.png","SouthAfrica"));
            flags.Add(new FlagQuiz.Flag(7, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\spain.png","Spain"));
            flags.Add(new FlagQuiz.Flag(8, "C:\\Users\\owner\\Documents\\C#\\FlagQuiz\\FlagQuiz\\images\\unitedstates.png","UnitedStates"));
        }

        public int PickFlag()
        {
            int num = -1;
            available = false;
            while (flagsAvailable.Count != 0 && !available) {
                num = RandomNumber();
                foreach (int i in flagsAvailable) {
                    if (num == i) {
                        available = true;
                        break;
                    }
                }
            }
            return num;
        }

        public int RandomNumber()
        {
            Random rand = new Random();
            int num = rand.Next(1, 9);
            return num;
        }


        public void FlagWasUsed(int num)
        {
            flagsAvailable.Remove(num);
        }


        public Flag GetFlag()
        {
            int i = PickFlag();
            if (i != -1) {
                currentFlag = flags[i-1];
                return currentFlag;          
            }
            return currentFlag = null;
        }






    }
}
