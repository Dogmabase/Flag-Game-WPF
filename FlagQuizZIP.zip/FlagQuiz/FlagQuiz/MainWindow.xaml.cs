﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

/// <summary>
/// Flag Quiz Game
/// 
/// Caitlin Boake
/// 
/// </summary>

namespace FlagQuiz
{
    /// <summary>
    /// MainWindow.xaml
    /// 
    /// Uses the FlagQuizController to determine
    /// which flag to display, and whether the 
    /// flag selected is correct.
    /// 
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private bool correct = false;
        public string imgPath { get; set; }
        public ObservableCollection<Flag> flags { get; set; } = new ObservableCollection<Flag>();
        public Flag currentFlag { get; set; }
        public string selectedCountry { get; set; }

        private FlagQuizController flagController = new FlagQuizController();

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string PropertyName)
        {
            if (PropertyChanged != null) {
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            foreach (Flag f in flagController.flags) {
                flags.Add(f);
            }

            currentFlag = flagController.GetFlag();
            if (currentFlag != null) {
                imgPath = currentFlag.FlagPath;
            }
        }



        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCountry == currentFlag.CountryName) {
                txbMessage.Text = "Correct!\nPress Next to continue.";

                if (flagController.flagsAvailable.Count() == 1) {
                    txbScore.Text = "8/8";
                    txbMessage.Text = "Game Over!";
                }
                else {
                    txbScore.Text = (9 - flagController.flagsAvailable.Count()) + "/8";
                }

                correct = true;
            }
            else {
                txbMessage.Text = "Please try again.";
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            if (correct) {                              

                if (flagController.flagsAvailable.Count != 1) {
                    flagController.FlagWasUsed(currentFlag.FlagID);
                    currentFlag = flagController.GetFlag();
                    if (currentFlag != null) {
                        imgPath = currentFlag.FlagPath;
                        NotifyPropertyChanged("imgPath");
                        txbMessage.Text = string.Empty;
                    }
                    correct = false;
                }
                else {
                    txbMessage.Text = "Game Over!";
                }

            }
            else {
                txbMessage.Text = "Please check\nyour selection";
            }
            

        }


        private void cbxCountries_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            txbMessage.Text = string.Empty;
            ComboBox cbx = new ComboBox();
            cbx = sender as ComboBox;
            Flag f = (Flag)cbx.SelectedItem;
            selectedCountry = f.CountryName;
        }
    }
}
