﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlagQuiz
{
    public class Flag
    {

        public int FlagID { get; set; }
        public string FlagPath { get; set; }
        public string CountryName { get; set; }

        public Flag()
        {
        }

        public Flag(int id, string path, string name)
        {
            FlagID = id;
            FlagPath = path;
            CountryName = name;
        }



    }
}
